<template>
    <div :style="{ left: position.x + 'px', top: position.y + 'px', transform: 'rotateZ(' + deg + 'deg) rotateY(' + deg_y + 'deg)' }">
      <img :src="petSrc" :style="{ width: petWidth + 'px' }" @click="handleClick">
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        petSrc: "./img/Idle.gif",
        petWidth: 50,
        deg: 0,
        deg_y: 0,
        mousePosition: { x: 0, y: 0 },
        position: { x: 0, y: 0 },
        count: 0,
        speed: 50,
        isCatchUp: false,
        isClick: false,
        isIdle: true,
        attack: { current: 0, max: 340 },
        click: { current: 0, max: 40 },
        walk: { current: 0, max: 130 },
      };
    },
    methods: {
      handleClick() {
        this.isClick = true;
      },
      handleMouseMove(event) {
        this.mousePosition.x = event.x - this.$el.offsetLeft - this.$el.clientWidth / 2;
        this.mousePosition.y = event.y - this.$el.offsetTop - this.$el.clientHeight / 2;
        this.deg = 360 * Math.atan(this.mousePosition.y / this.mousePosition.x) / (2 * Math.PI);
  
        if (this.$el.offsetLeft > event.clientX) {
          this.deg_y = -180;
        } else {
          this.deg_y = 0;
        }
  
        this.count = 0;
      },
      updatePetPosition() {
        if (this.isCatchUp === false && this.isIdle === false) {
          this.catchUpState();
        } else if (this.isCatchUp === true && this.isIdle === false) {
          this.attackState();
        } else if (this.isClick === true) {
          this.clickState();
        }
      },
      catchUpState() {
        if (this.walk.current === 0) {
          this.petSrc = "./img/Walk.gif";
          this.petWidth = 50;
          this.walk.current++;
        } else if (this.walk.current < this.walk.max) {
          if (this.count < this.speed) {
            this.position.x += this.mousePosition.x / this.speed;
            this.position.y += this.mousePosition.y / this.speed;
          } else {
            this.isCatchUp = true;
            this.walk.current = 0;
          }
          this.count++;
          this.walk.current++;
        } else if (this.walk.current >= this.walk.max) {
          this.walk.current = 0;
          this.petWidth = 50;
          this.petSrc = "./img/Walk.gif";
        }
      },
      attackState() {
        if (this.attack.current === 0) {
          this.petSrc = "./img/Attack.gif";
          this.petWidth = 100;
          this.attack.current++;
        } else if (this.attack.current < this.attack.max) {
          this.attack.current++;
        } else if (this.attack.current >= this.attack.max) {
          this.isCatchUp = false;
          this.isIdle = true;
          this.attack.current = 0;
          this.petSrc = "./img/Idle.gif";
          this.petWidth = 50;
        }
      },
      clickState() {
        if (this.click.current === 0) {
          this.petSrc = "./img/Hit.gif";
          this.petWidth = 60;
          this.click.current++;
        } else if (this.click.current < this.click.max) {
          this.click.current++;
        } else if (this.click.current >= this.click.max) {
          this.click.current = 0;
          this.petSrc = "./img/Walk.gif";
          this.petWidth = 50;
          this.isClick = false;
          this.isIdle = false;
        }
      },
    },
    mounted() {
      window.addEventListener('mousemove', this.handleMouseMove);
      setInterval(this.updatePetPosition, 10);
    },
    beforeDestroy() {
      window.removeEventListener('mousemove', this.handleMouseMove);
    },
  };
  </script>
  