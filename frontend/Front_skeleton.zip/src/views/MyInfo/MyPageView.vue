<!-- <template>
  <div>
    <button @click="toggleRecording">{{ isRecording ? '종료' : '시작' }}</button>
    <br><br>
    <audio ref="audioEl" controls></audio>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';

import axios from 'axios';

export default {
  setup() {
    const isRecording = ref(false);
    const audioEl = ref(null);
    const audioArray = ref([]);
    let mediaRecorder = null;

    const toggleRecording = async () => {
      if(!isRecording.value){
        const mediaStream = await navigator.mediaDevices.getUserMedia({audio: true});
        mediaRecorder = new MediaRecorder(mediaStream);

        mediaRecorder.ondataavailable = (event)=>{
          audioArray.value.push(event.data);
        }

        mediaRecorder.onstop = async ()=>{
        const blob = new Blob(audioArray.value, {"type": "audio/wav"});
        audioArray.value.splice(0);
        const blobURL = window.URL.createObjectURL(blob);
        audioEl.value.src = blobURL;
        audioEl.value.play();

        // Clova Speech API 요청 코드 추가
        let formData = new FormData();
        formData.append('media', blob);
        const res = await axios.post('https://clovaspeech-gw.ncloud.com/external/v1/6820/7881eddfe386c9831f86d5865409a071362181f34e97e0d9c0a6c574dd25de3e', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
            'X-CLOVASPEECH-API-KEY': '1377d300f8254766b464a13d95f63af0'
          }
        });

        console.log(res.data);
      }

        mediaRecorder.start();
        isRecording.value = true;

      }else{
        mediaRecorder.stop();
        isRecording.value = false;
      }
    }
    
    return {
      isRecording,
      audioEl,
      toggleRecording
    }
  }
}
</script> -->
<template>
  <div>
    <img id="pet" src="./img/Idle.gif" alt="Pet" />
  </div>
</template>

<script>
export default {
  data() {
    return {
      pet: null,
      deg: 0,
      deg_y: 0,
      mousePosition: { x: 0, y: 0 },
      position: { x: 0, y: 0 },
      count: 0,
      speed: 50,
      isCatchUp: false,
      isClick: false,
      isIdle: true,
      attack: { current: 0, max: 340 },
      click: { current: 0, max: 40 },
      walk: { current: 0, max: 130 },
    };
  },
  mounted() {
    this.pet = document.getElementById('pet');

    this.pet.onclick = () => {
      this.isClick = true;
    };

    window.addEventListener('mousemove', (event) => {
      this.mousePosition.x = event.x - this.pet.offsetLeft - this.pet.clientWidth / 2;
      this.mousePosition.y = event.y - this.pet.offsetTop - this.pet.clientHeight / 2;
      this.deg = (360 * Math.atan(this.mousePosition.y / this.mousePosition.x)) / (2 * Math.PI);

      if (this.pet.offsetLeft > event.clientX) {
        this.deg_y = -180;
      } else {
        this.deg_y = 0;
      }

      this.count = 0;
    });

    setInterval(this.updatePet, 10);
  },
  methods: {
    updatePet() {
      if (!this.isCatchUp && !this.isIdle) {
        this.catchUpState();
      } else if (this.isCatchUp && !this.isIdle) {
        this.attackState();
      } else if (this.isClick) {
        this.clickState();
      }
    },
    catchUpState() {
      if (this.walk.current === 0) {
        this.pet.src = './img/Walk.gif';
        this.pet.style.width = '50px';
        this.walk.current++;
      } else if (this.walk.current < this.walk.max) {
        this.pet.style.transform = `rotateZ(${this.deg}deg) rotateY(${this.deg_y}deg)`;

        if (this.count < this.speed) {
          this.position.x += this.mousePosition.x / this.speed;
          this.position.y += this.mousePosition.y / this.speed;
        } else {
          this.isCatchUp = true;
          this.walk.current = 0;
        }

        this.pet.style.left = `${this.position.x}px`;
        this.pet.style.top = `${this.position.y}px`;
        this.count++;
        this.walk.current++;
      } else if (this.walk.current >= this.walk.max) {
        this.walk.current = 0;
        this.pet.style.width = '50px';
        this.pet.src = './img/Walk.gif';
      }
    },
    attackState() {
      if (this.attack.current === 0) {
        this.pet.src = './img/Attack.gif';
        this.pet.style.width = '100px';
        this.attack.current++;
      } else if (this.attack.current < this.attack.max) {
        this.attack.current++;
      } else if (this.attack.current >= this.attack.max) {
        this.isCatchUp = false;
        this.isIdle = true;
        this.attack.current = 0;
        this.pet.src = './img/Idle.gif';
        this.pet.style.width = '50px';
      }
    },
    clickState() {
      if (this.click.current === 0) {
        this.pet.src = './img/Hit.gif';
        this.pet.style.width = '60px';
        this.click.current++;
      } else if (this.click.current < this.click.max) {
        this.click.current++;
      } else if (this.click.current >= this.click.max) {
        this.click.current = 0;
        this.pet.src = './img/Walk.gif';
        this.pet.style.width = '50px';
        this.isClick = false;
        this.isIdle = false;
      }
    },
  },
};
</script>

<style scoped>
.div {
  width: 1024px;
  height: 720px;
  
}
.pet {
        width: 50px;
        height: 65px;
        position: absolute;
        background-size: cover;
    }
</style>
