<template>
  <div v-if="isModal" class="modal" @click.self="closeModal">
    <div class="modal-content" @click.stop>
      <div class="d-flex justify-content-between">
        <h3>비밀번호 변경</h3>
        <button class="btn btn-danger" @click="closeModal">X</button>
      </div>
      <el-form :model="state.form" :rules="state.rules" ref="changePasswordForm" :label-position="state.formAlign">
        <el-form-item prop="originalPassword" label="현재 비밀번호" :label-width="state.formLabelWidth">
          <el-input v-model="state.form.originalPassword" :rules="state.rules.originalPassword" autocomplete="off" show-password></el-input>
        </el-form-item>
        <el-form-item prop="password" label="새로운 비밀번호" :label-width="state.formLabelWidth">
          <el-input v-model="state.form.password" :rules="state.rules.password" autocomplete="off" show-password></el-input>
        </el-form-item>
        <el-form-item prop="password2" label="비밀번호 확인" :label-width="state.formLabelWidth">
          <el-input v-model="state.form.password2" :rules="state.rules.password2" autocomplete="off" show-password></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :disabled="!isFormValid">비밀번호 변경</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script setup>
import { reactive, computed } from 'vue'
const props = defineProps({
  isModal: Boolean
})

const emit = defineEmits(['closeModal'])
const closeModal = function () {
  emit('closeModal')
}

const state = reactive({
  form: {
    originalPassword: '',
    password: '',
    password2: '',
  },
  rules: {
    originalPassword: [
      { required: true, message: '필수 입력 항목입니다.', trigger: 'change' },
      { min: 9, message: '최소 9자를 입력 해야합니다.', trigger: 'change' },
      { max: 16, message: '최대 16자까지 입력 가능합니다.', trigger: 'change' },
      { validator: (rule, value, callback) => {
        if (!/(?=.*[a-z])(?=.*\d)(?=.*\W)/.test(value)) {
          callback(new Error('비밀번호는 영문, 숫자, 특수문자가 조합되어야합니다.'))
        } else {
          callback()
        }
      }, trigger: 'change' }
    ],
    password: [
      { required: true, message: '필수 입력 항목입니다.', trigger: 'change' },
      { min: 9, message: '최소 9자를 입력 해야합니다.', trigger: 'change' },
      { max: 16, message: '최대 16자까지 입력 가능합니다.', trigger: 'change' },
      { validator: (rule, value, callback) => {
        if (!/(?=.*[a-z])(?=.*\d)(?=.*\W)/.test(value)) {
          callback(new Error('비밀번호는 영문, 숫자, 특수문자가 조합되어야합니다.'))
        } else {
          callback()
        }
      }, trigger: 'change' }
    ],
    password2: [
      { required: true, message: '필수 입력 항목입니다.', trigger: 'change' },
      { min: 9, message: '최소 9자를 입력 해야합니다.', trigger: 'change' },
      { max: 16, message: '최대 16자까지 입력 가능합니다.', trigger: 'change' },
      { validator: (rule, value, callback) => {
        if (!/(?=.*[a-z])(?=.*\d)(?=.*\W)/.test(value)) {
          callback(new Error('비밀번호는 영문, 숫자, 특수문자가 조합되어야합니다.'))
        } else {
          callback()
        }
      }, trigger: 'change' },
      {
        validator: (rule, value, callback) => {
          if (value !== state.form.password) {
            callback(new Error('입력한 비밀번호와 일치하지 않습니다.'))
          } else {
            callback()
          }
        }, trigger: 'change'
      }
    ],
  },
  formLabelWidth: '120px',
  formAlign: 'left',
})

const isFormValid = computed(() => {
  const rules = state.rules
  const form = state.form
  // 다 맞는지 확인하는 변수
  let isValid = true

  for (const key in rules) {
    if (rules[key]) {
      const itemRules = rules[key]
      for (const rule of itemRules) {
        if (rule.required && !form[key]) {
          isValid = false   // 필수사항인데 적힌게 없는 경우
          break
        }
        if (rule.validator) {
          const validatorCallback = (error) => {
            if (error) {
              isValid = false // 유효성 검사를 통과하지 못한 경우
            }
          }
          rule.validator({}, form[key], validatorCallback)
        }
      }
    }
  }
  return isValid
})
</script>

<style scoped>
.modal {
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background: rgba(0, 0, 0, 0.5);
display: flex;
justify-content: center;
align-items: center;
}
.modal-content {
width : 400px;
}
</style>